package org.helloworld2.com.server;

import org.helloworld2.com.client.GreetingService;
import org.helloworld2.com.shared.*;

import com.google.gwt.thirdparty.guava.common.io.Files;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import java.sql.*;
import java.util.ArrayList;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
import java.io.File;
//import java.nio.*;
//import java.io.FilePermission;
/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class GreetingServiceImpl extends RemoteServiceServlet implements
		GreetingService {
	//to read a file use :: Files.toByteArray(file);
	//see => http://docs.guava-libraries.googlecode.com/git/javadoc/com/google/common/io/Files.html#toByteArray(java.io.File)
    protected Connection connection;
	public ArrayList<FTree> transferAndLoadFiles() throws IllegalArgumentException
	{
		ArrayList<FTree> res = null;
		if( init_database() == false )
			return res;
		try
		{
			DatabaseMetaData dbmd = connection.getMetaData();
			String[] db_types = {"TABLE"};
			ResultSet rs = dbmd.getTables(null,  null, "%", db_types);
			
			boolean found_table = false;
			for( ; rs.next(); )
			{
				if( rs.getString(3).equalsIgnoreCase("LONIDB") )//MYOTHERTABLE
				{
					found_table = true;
					break;
				}
			}
			rs.close();
			if( found_table == true )
			{
				res = collectFilesAndUpdateDB(".").children;
				/*Statement st = connection.createStatement();
				ResultSet rs2 = st.executeQuery("SELECT * FROM MYOTHERTABLE");
				for( ; rs2.next(); )
				{
					//res += "ID = " + rs2.getString(1) +
					//	   "FIRSTNAME = " + rs2.getString(2) + 
					//	   "NAME = " + rs2.getString(3) +
					//	   "ZIP = " + rs2.getString(4) + " || ";
				}
				rs2.close();
				st.close();*/
			}
			else //database yet does not exist, so create it and send all the info in...
			{
				Statement st = connection.createStatement();
				st.executeQuery("CREATE TABLE LONIDB( ABS_PATH_WITH_NAME VARCHAR(1024) PRIMARY KEY, FILE_NAME VARCHAR(1024), PERM VARCHAR(1024), LIST_USERS VARCHAR(1024), LIST_GROUPS VARCHAR(1024));");
				//
				res = collectFilesAndWriteInDatabase(".").children;
			}
			connection.close();
		}
		catch(Exception e)
		{
			return null;
		} 
		//return collectFiles(".").children;
		return res;
	}
	
	public FTree collectFilesAndWriteInDatabase(String folder_name) //assumes that DB did not existed so far, and now whonce it was just created it is empty...
	{
		File dir = new File(folder_name);
		
		String filename[] = null;
		if( dir.isDirectory() )
		{
				filename = dir.list();
		}
		FTree res = new FTree();
		res.name = folder_name;
		res.folder = true;
		for( int i = 0; i < filename.length; i++ )
		{
			if( (new File(folder_name + '\\' + filename[i])).isDirectory() )
			{
				res.children.add(collectFilesAndWriteInDatabase(folder_name + '\\' + filename[i]));
			}
			else
			{
				FTree non_folder_child = new FTree();
				non_folder_child.name = folder_name + '\\' + filename[i];
				non_folder_child.folder = false;
				try
				{
					res.children.add(non_folder_child);
					Statement st = connection.createStatement();
					ResultSet rs = st.executeQuery("INSERT INTO LONIDB VALUES (\'" + folder_name + '\\' + filename[i] + "\', \'" + filename[i] + "\', \'xrwxrwxrw\', \'USER\', \'GROUP\');");
					rs.close();
					st.close();
				}
				catch(Exception e)
				{
					return null;
				}
			}
		}
		return res;
	}
	
	public FTree collectFilesAndUpdateDB(String folder_name)	//assumes that DB already exists; this func updates DB
	{
		File dir = new File(folder_name);
		String filename[] = null;
		if( dir.isDirectory() )
		{
				filename = dir.list();
		}
		FTree res = new FTree();
		res.name = folder_name;
		res.folder = true;
		for( int i = 0; i < filename.length; i++ )
		{
			if( (new File(folder_name + '\\' + filename[i])).isDirectory() )
			{
				res.children.add(collectFilesAndUpdateDB(folder_name + '\\' + filename[i]));
			}
			else
			{
				FTree non_folder_child = new FTree();
				non_folder_child.name = folder_name + '\\' + filename[i];
				non_folder_child.folder = false;
				//add to database
				try
				{
					Statement st = connection.createStatement();
					ResultSet rs = st.executeQuery("SELECT * FROM LONIDB WHERE LONIDB.ABS_PATH_WITH_NAME = \'" + folder_name + '\\' + filename[i] + "\';");
					boolean found_item = false;
					for( ; rs.next(); )
					{
						if( rs.getString(2).equalsIgnoreCase(filename[i]) == false 
					  // || rs.getString(3).equalsIgnoreCase( file perm ) == false 
					  // || rs.getString(4).equalsIgnoreCase( list of accessing users ) == false 
					  // || rs.getString(5).equalsIgnoreCase( list of accessing groups ) == false
						  )
						{
							//found_item = true;
							//Statement st2 = connection.createStatement();
							ResultSet rs2 = st.executeQuery("DELETE FROM LONIDB WHERE LONIDB.ABS_PATH_WITH_NAME = \'" + folder_name + '\\' + filename[i] + "\';");// INSERT INTO LONIDB VALUES (\'" + folder_name + '\\' + filename[i] + "\', \'" + filename[i] + "\', \'xrwxrwxrw\', \'USER\', \'GROUP\');");
							rs2.close();
							non_folder_child.name += "DEL";
							//st2.close();
						}
						else
						{
							non_folder_child.name += "EXIST";
							found_item = true;
						}
					}
					if( found_item == false )
					{
						//Statement st2 = connection.createStatement();
						ResultSet rs2 = st.executeQuery("INSERT INTO LONIDB VALUES (\'" + folder_name + '\\' + filename[i] + "\', \'" + filename[i] + "\', \'xrwxrwxrw\', \'USER\', \'GROUP\');");
						rs2.close();
						non_folder_child.name += "INS";
						//st2.close();
					}
					rs.close();
					st.close();
					res.children.add(non_folder_child);
				}
				catch(Exception e)
				{
					return null;
				}
			}
		}
		return res;
	}
	
	public boolean init_database()
	{
		try
		{
			Class.forName("org.hsqldb.jdbcDriver").newInstance();//org.hsqldb.jdbc.JDBCDriver");//
		}
		catch(Exception e)
		{
			System.err.println("JDBC_DRIVER FAILED");
			e.printStackTrace();
			return false;
		}
		try
		{
			connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost:9001/xdb", "sa", "");
		}
		catch(Exception e)
		{
			System.err.println("THERE IS ANOTHER ERROR");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public ArrayList<FTree> transferFiles() throws IllegalArgumentException 
	{
		return collectFiles(".").children;
	}
	
	public FTree collectFiles(String folder_name)
	{
		File dir = new File(folder_name);
		
		String filename[] = null;
		if( dir.isDirectory() )
		{
				filename = dir.list();
		}
		FTree res = new FTree();
		res.name = folder_name;
		res.folder = true;
		for( int i = 0; i < filename.length; i++ )
		{
			if( (new File(folder_name + '\\' + filename[i])).isDirectory() )
			{
				res.children.add(collectFiles(folder_name + '\\' + filename[i]));
			}
			else
			{
				FTree non_folder_child = new FTree();
				non_folder_child.name = folder_name + '\\' + filename[i];
				non_folder_child.folder = false;
				res.children.add(non_folder_child);
			}
		}
		return res;
	}
	
	public ArrayList<FTree> queryDatabase(String input) throws IllegalArgumentException {
		// Verify that the input is valid. 
		/*if (!FieldVerifier.isValidName(input)) {
			// If the input is not valid, throw an IllegalArgumentException back to
			// the client.
			throw new IllegalArgumentException(
					"Name must be at least 4 characters long");
		}*/
		//String res = "";
		//String serverInfo = getServletContext().getServerInfo();
		//String userAgent = getThreadLocalRequest().getHeader("User-Agent");

		// Escape data from the client to avoid cross-site script vulnerabilities.
		//input = escapeHtml(input);
		//userAgent = escapeHtml(userAgent);
		//
		ArrayList<FTree> res = new ArrayList<FTree>();
		try
		{
			Class.forName("org.hsqldb.jdbcDriver").newInstance();//org.hsqldb.jdbc.JDBCDriver");//
		}
		catch(Exception e)
		{
			System.err.println("JDBC_DRIVER FAILED");
			e.printStackTrace();
			FTree temp = new FTree();
			temp.name = "Eception # 1";
			res.add(temp);
			return res;
		}
		//res += "JDBC_DRIVER WORKED!!  ";
		try
		{
			Connection c = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost:9001/xdb", "sa", "");
			//Connection c = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/animaldb", "sa", "");
			//Connection c = DriverManager.getConnection("jdbc:hsqldb:file:C:\\JavaEE\\IDEs\\eclipse\\workspace\\helloworld2\\war\\WEB-INF\\lib\\mydb", "sa", "");
			//DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb ;shutdown=true", "SA", "");
			//res += "MANAGED CONNECTION!!  ";
			
			//Statement st = c.createStatement();
			//ResultSet rs = st.executeQuery("SELECT * FROM TABLE1");
			
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM LONIDB WHERE LONIDB.FILE_NAME = \'" + input + "\'");
			for( ; rs.next(); )
			{
				FTree query_item = new FTree();
				query_item.name = rs.getString(2);
				query_item.folder = false;
				res.add(query_item);
			}
			st.close();
			rs.close();
			c.close(); 
		}
		catch(Exception e)
		{
			System.err.println("THERE IS ANOTHER ERROR");
			e.printStackTrace();
			FTree temp = new FTree();
			temp.name = "EXCEPTION # 2";
			res.add(temp);
			return res;
		}
		return res;
	}

	/**
	 * Escape an html string. Escaping data received from the client helps to
	 * prevent cross-site script vulnerabilities.
	 * 
	 * @param html the html string to escape
	 * @return the escaped string
	 */
/*	private String escapeHtml(String html) {
		if (html == null) {
			return null;
		}
		return html.replaceAll("&", "&amp;").replaceAll("<", "&lt;")
				.replaceAll(">", "&gt;");
	}*/
}
