package org.helloworld2.com.client;

import java.util.ArrayList;
import com.google.gwt.user.client.rpc.AsyncCallback;
import org.helloworld2.com.shared.*;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface GreetingServiceAsync {
	void queryDatabase(String input, AsyncCallback<ArrayList<FTree>> callback)
			throws IllegalArgumentException;
	void transferFiles(AsyncCallback<ArrayList<FTree>> callback) throws IllegalArgumentException;
	void transferAndLoadFiles(AsyncCallback<ArrayList<FTree>> callback) throws IllegalArgumentException;
	//void getFile(String input_name, AsyncCallback<pipefile> callback) throws IllegalArgumentException;
}
