package org.helloworld2.com.shared;

import java.util.ArrayList;

public class FTree implements java.io.Serializable
{
	public String name;
	public boolean folder;
	public ArrayList<FTree> children;
	private static final long serialVersionUID = 999L;
	public FTree()
	{
		name = "name_";
		folder = false;
		children = new ArrayList<FTree>();
	}
}