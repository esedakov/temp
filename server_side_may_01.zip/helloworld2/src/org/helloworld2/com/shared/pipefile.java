package org.helloworld2.com.shared;

public class pipefile implements java.io.Serializable
{
	public String name;
	public String access_restrictions;
	public String XML_file;
	private static final long serialVersionUID = 998L;
	public pipefile()
	{
		name = "name_";
		access_restrictions = "xrwxrwxrw";
		XML_file = "";
	}
}