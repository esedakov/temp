package org.helloworld2.com.shared;

//import java.util.ArrayList;

public class FileTree {
	/*public String name;
	public boolean folder;
	//public ArrayList<FileTree> children;
	public FileTree()
	{
		name = "";
		folder = false;
		//children = new ArrayList<FileTree>();
	}
	public FileTree(String ft_name, boolean ft_isFolder)
	{
		name = ft_name;
		folder = ft_isFolder;
		//children = new ArrayList<FileTree>();
	}*/
}